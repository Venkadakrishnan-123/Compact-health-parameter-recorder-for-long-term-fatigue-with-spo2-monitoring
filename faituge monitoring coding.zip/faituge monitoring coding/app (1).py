from flask import Flask, render_template, request
import pandas as pd
import os
import plotly.express as px
import plotly
import json
import requests
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)

# ---------------- AI SUMMARY ---------------- #
def get_ai_summary(df):
    API_KEY = os.getenv("OPENROUTER_API_KEY")

    latest = df.iloc[-1]

    prompt = f"""
    Analyze this health data:
    Heart Rate: {latest['heartrate']}
    SpO2: {latest['spo2']}
    Temperature: {latest['temperature']}
    Fatigue Score: {latest['fatiguescore']}

    Provide:
    - Health Status
    - Risk Level
    - Advice
    """

    try:
        response = requests.post(
            "https://openrouter.ai/api/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {API_KEY}",
                "Content-Type": "application/json"
            },
            json={
                "model": "meta-llama/llama-3-8b-instruct",
                "messages": [{"role": "user", "content": prompt}]
            }
        )

        result = response.json()
        return result["choices"][0]["message"]["content"]

    except:
        return "⚠ AI not available"

# ---------------- FALLBACK ---------------- #
def rule_based_summary(df):
    latest = df.iloc[-1]

    if latest['spo2'] < 90 or latest['temperature'] > 38:
        return "🔴 Critical condition. Seek medical help."
    elif latest['fatiguescore'] > 60:
        return "🟡 Moderate fatigue. Take rest."
    else:
        return "🟢 Stable condition."

# ---------------- MAIN ROUTE ---------------- #
@app.route('/', methods=['GET', 'POST'])
def upload_file():
    graphs = None
    table_html = None
    summary = None
    health_score = None

    if request.method == 'POST':
        file = request.files['file']
        df = pd.read_csv(file)

        df.columns = df.columns.str.strip().str.lower()

        # Timestamp handling
        ts_col = df.columns[0]
        df['timestamp'] = pd.to_datetime(df[ts_col], errors='coerce')

        df['danger'] = ((df['heartrate'] > 120) | 
                        (df['spo2'] < 90) | 
                        (df['temperature'] > 38))

        # Health score
        danger_count = df['danger'].sum()
        health_score = max(100 - danger_count * 5, 0)

        # Graphs
        line_fig = px.line(df, x='timestamp',
                           y=['heartrate','spo2','temperature','fatiguescore'],
                           title='Health Data Over Time')

        line_json = json.dumps(line_fig, cls=plotly.utils.PlotlyJSONEncoder)

        pie_df = df['danger'].value_counts().reset_index()
        pie_df.columns = ['status', 'count']

        pie_fig = px.pie(pie_df, names='status', values='count')
        pie_json = json.dumps(pie_fig, cls=plotly.utils.PlotlyJSONEncoder)

        graphs = {'line': line_json, 'pie': pie_json}

        # AI Summary
        summary = get_ai_summary(df)

        if not summary or "⚠" in summary:
            summary = rule_based_summary(df)

        table_html = df.to_html(classes='data', index=False)

    return render_template('index.html',
                           graphs=graphs,
                           table_html=table_html,
                           summary=summary,
                           health_score=health_score)

if __name__ == "__main__":
    app.run(debug=True)