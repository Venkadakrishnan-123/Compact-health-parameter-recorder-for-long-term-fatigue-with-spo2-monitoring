import requests
import os
from dotenv import load_dotenv

load_dotenv()

# ✅ correct
API_KEY = os.getenv("OPENROUTER_API_KEY")

print("KEY:", API_KEY)

response = requests.post(
    "https://openrouter.ai/api/v1/chat/completions",
    headers={
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    },
    json={
        "model": "meta-llama/llama-3-8b-instruct",
        "messages": [
            {"role": "user", "content": "Hello"}
        ]
    }
)

print("Status:", response.status_code)
print(response.text)